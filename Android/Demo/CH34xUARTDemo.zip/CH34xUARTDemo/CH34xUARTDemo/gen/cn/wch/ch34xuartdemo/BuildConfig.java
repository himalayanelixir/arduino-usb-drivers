/** Automatically generated file. DO NOT MODIFY */
package cn.wch.ch34xuartdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}